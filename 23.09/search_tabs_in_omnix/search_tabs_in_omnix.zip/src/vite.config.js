export default {
    base: './', // 将生成的静态资源的路径修改为当前路径
  }